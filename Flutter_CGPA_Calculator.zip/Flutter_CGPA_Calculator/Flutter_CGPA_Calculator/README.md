# cgpa_calculator_Flutter


samples, guidance on mobile development, and a full API reference.
![HomaPage](https://user-images.githubusercontent.com/63815890/93190531-4e8f6780-f765-11ea-9a06-f3b6fe375ab5.png)
![AlertDialogBox](https://user-images.githubusercontent.com/63815890/93190534-4f27fe00-f765-11ea-80f7-69fcc97765d9.png)
![CGPA Page](https://user-images.githubusercontent.com/63815890/93190524-4c2d0d80-f765-11ea-8f6f-03a2983a55e2.png)
![CGPA Result Page](https://user-images.githubusercontent.com/63815890/93190526-4e8f6780-f765-11ea-8af4-c135089c56c7.png)

