import 'package:flutter/material.dart';
import 'gpaScreens/HomePage.dart';

void main() {
  runApp(new MaterialApp(
    debugShowCheckedModeBanner: false,
    home: HomePage())
  );
}