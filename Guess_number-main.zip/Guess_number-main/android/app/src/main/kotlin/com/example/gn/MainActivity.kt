package com.example.gn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
